<!doctype html>
<html>
	<head>
		<title>DGPT4711 Lab 06</title>
	</head>
	<body>
		<h1>Travel Destinations</h1>
		<p><a href="/travel">Show the destinations</a>.</p>
		<p><a href="/places">Show the places raw data</a></p>
	</body>
</html>