<!doctype html>
<html>
	<head>
		<title>DGPT4711 Lab 04</title>
	</head>
	<body>
		<h1>One Travel Destinations</h1>
		<p><strong>ID:</strong> {id}</p>
		<p><strong>Name:</strong> {name}</p>
		<p><strong>Description:</strong> {description}</p>
		<p><strong>Tourism site:</strong> {link}</p>
		<p><img src="/image/{image}"/></p>
		<p><a href="/home">Home</a></p>
	</body>
</html>