<!doctype html>
<html>
	<head>
		<title>DGPT4711 Lab 04</title>
	</head>
	<body>
		<h1>List of Travel Destinations</h1>
		{records}
		<p><a href="/travel/showme/{id}">{name}</a></p>
		{/records}
		<p><a href="/home">Home</a></p>
	</body>
</html>